require 'spec_helper'

describe IdeasController do

end
