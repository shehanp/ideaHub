require 'spec_helper'

describe DiscussionsController do

end
