require 'spec_helper'

describe FavouritesController do

end
