require 'spec_helper'

describe "users/:destroy.html.haml" do
  pending "add some examples to (or delete) #{__FILE__}"
end
