module ApplicationHelper

def formatted_date(date)
    date.strftime("%Y-%B-%d")   
end

end
